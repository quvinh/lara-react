export const inventory = (data) => {
    return {
        type: "INVENTORY",
        payload: data,
    };
};
